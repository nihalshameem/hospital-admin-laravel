<?php
$conn=mysqli_connect("localhost","niraisool_hospital_user","=RNVWYd_qsj[") or die("Could not connect");
mysqli_select_db($conn,"niraisool_hospital") or die("could not connect database");
?>