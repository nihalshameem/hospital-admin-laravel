<div class="deznav">
    <div class="deznav-scroll">
        <ul class="metismenu" id="menu">
            <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
                    <i class="flaticon-381-networking"></i>
                    <span class="nav-text">Dashboard</span>
                </a>
                <ul aria-expanded="false">
                    <li><a href="{!! url('/home') !!}">Dashboard</a></li>
                    
                    
                       <li><a href=" https://niraisool.com/excel/index.php">Excel File Upload</a></li>
                   
                    <!----------
                    <li><a href="{!! url('mother-upload') !!}">Mother Upload</a></li>
                    !---->
                    
                    <li><a href="{!! url('patient') !!}">Mother Registration</a></li>
                        <li><a href="{!! url('mother-medical') !!}">Mother Medical</a></li>
                            <li><a href="{!! url('an-mother-visit') !!}">Mother AN Visit</a></li>
                                <li><a href="{!! url('#') !!}">Reports</a></li>
                                
                </ul>
            </li>

        </ul>

      
    </div>
</div>
