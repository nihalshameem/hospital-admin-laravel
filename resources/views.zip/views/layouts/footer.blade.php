<div class="footer">
	<div class="copyright">
		<p>Copyright © Developed by <a href="https://niraisool.in" target="_blank">நிறைசூல் </a> 2022</p>
	</div>
</div>